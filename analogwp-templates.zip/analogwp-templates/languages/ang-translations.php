<?php
/* THIS IS A GENERATED FILE. DO NOT EDIT DIRECTLY. */
$generated_i18n_strings = array(
	/* Copyright (C) 2020 AnalogWP
	   This file is distributed under the same license as the Style Kits for Elementor plugin. */
,

	// Reference: inc/admin/class-admin.php:44
	// Reference: inc/class-tracker.php:131
	// Reference: inc/register-settings.php:26
	// Reference: languages/ang-translations.php:14
	/* translators: Plugin Name of the plugin
translators: Plugin Name of the plugin translators: Plugin Name of the plugin translators: Plugin Name of the plugin translators: Plugin Name of the plugin translators: Plugin Name of the plugin translators: Plugin Name of the plugin translators: Plugin Name of the plugin translators: Plugin Name of the plugin translators: Plugin Name of the plugin translators: Plugin Name of the plugin translators: Plugin Name of the plugin translators: Plugin Name of the plugin translators: Plugin Name of the plugin translators: Plugin Name of the plugin translators: Plugin Name of the plugin translators: Plugin Name of the plugin translators: Plugin Name of the plugin translators: Plugin Name of the plugin translators: Plugin Name of the plugin translators: Plugin Name of the plugin translators: Plugin Name of the plugin translators: Plugin Name of the plugin translators: Plugin Name of the plugin translators: Plugin Name of the plugin translators: Plugin Name of the plugin translators: Plugin Name of the plugin translators: Plugin Name of the plugin translators: Plugin Name of the plugin translators: Plugin Name of the plugin translators: Plugin Name of the plugin translators: Plugin Name of the plugin translators: Plugin Name of the plugin translators: Plugin Name of the plugin translators: Plugin Name of the plugin translators: Plugin Name of the plugin */
	__( 'Style Kits for Elementor', 'ang' ),

	// Reference: languages/ang-translations.php:20
	/* translators: Plugin URI of the plugin
Author URI of the plugin
translators: Plugin URI of the plugin Author URI of the plugin translators: Plugin URI of the plugin Author URI of the plugin translators: Plugin URI of the plugin Author URI of the plugin translators: Plugin URI of the plugin Author URI of the plugin translators: Plugin URI of the plugin Author URI of the plugin translators: Plugin URI of the plugin Author URI of the plugin translators: Plugin URI of the plugin Author URI of the plugin translators: Plugin URI of the plugin Author URI of the plugin translators: Plugin URI of the plugin Author URI of the plugin translators: Plugin URI of the plugin Author URI of the plugin translators: Plugin URI of the plugin Author URI of the plugin translators: Plugin URI of the plugin Author URI of the plugin translators: Plugin URI of the plugin Author URI of the plugin translators: Plugin URI of the plugin Author URI of the plugin translators: Plugin URI of the plugin Author URI of the plugin translators: Plugin URI of the plugin Author URI of the plugin translators: Plugin URI of the plugin Author URI of the plugin translators: Plugin URI of the plugin Author URI of the plugin translators: Plugin URI of the plugin Author URI of the plugin translators: Plugin URI of the plugin Author URI of the plugin translators: Plugin URI of the plugin Author URI of the plugin translators: Plugin URI of the plugin Author URI of the plugin translators: Plugin URI of the plugin Author URI of the plugin translators: Plugin URI of the plugin Author URI of the plugin translators: Plugin URI of the plugin Author URI of the plugin translators: Plugin URI of the plugin Author URI of the plugin translators: Plugin URI of the plugin Author URI of the plugin translators: Plugin URI of the plugin Author URI of the plugin translators: Plugin URI of the plugin Author URI of the plugin translators: Plugin URI of the plugin Author URI of the plugin translators: Plugin URI of the plugin Author URI of the plugin translators: Plugin URI of the plugin Author URI of the plugin translators: Plugin URI of the plugin Author URI of the plugin translators: Plugin URI of the plugin Author URI of the plugin translators: Plugin URI of the plugin Author URI of the plugin */
	__( 'https://analogwp.com/', 'ang' ),

	// Reference: languages/ang-translations.php:25
	/* translators: Description of the plugin
translators: Description of the plugin translators: Description of the plugin translators: Description of the plugin translators: Description of the plugin translators: Description of the plugin translators: Description of the plugin translators: Description of the plugin translators: Description of the plugin translators: Description of the plugin translators: Description of the plugin translators: Description of the plugin translators: Description of the plugin translators: Description of the plugin translators: Description of the plugin translators: Description of the plugin translators: Description of the plugin translators: Description of the plugin translators: Description of the plugin translators: Description of the plugin translators: Description of the plugin translators: Description of the plugin translators: Description of the plugin translators: Description of the plugin translators: Description of the plugin translators: Description of the plugin translators: Description of the plugin translators: Description of the plugin translators: Description of the plugin translators: Description of the plugin translators: Description of the plugin translators: Description of the plugin translators: Description of the plugin translators: Description of the plugin translators: Description of the plugin translators: Description of the plugin */
	__( 'Style Kits extends the Elementor theme styles editor with more global styling options. Boost your design workflow in Elementor with intuitive global controls and theme style presets.', 'ang' ),

	// Reference: languages/ang-translations.php:30
	/* translators: Author of the plugin
translators: Author of the plugin translators: Author of the plugin translators: Author of the plugin translators: Author of the plugin translators: Author of the plugin translators: Author of the plugin translators: Author of the plugin translators: Author of the plugin translators: Author of the plugin translators: Author of the plugin translators: Author of the plugin translators: Author of the plugin translators: Author of the plugin translators: Author of the plugin translators: Author of the plugin translators: Author of the plugin translators: Author of the plugin translators: Author of the plugin translators: Author of the plugin translators: Author of the plugin translators: Author of the plugin translators: Author of the plugin translators: Author of the plugin translators: Author of the plugin translators: Author of the plugin translators: Author of the plugin translators: Author of the plugin translators: Author of the plugin translators: Author of the plugin translators: Author of the plugin translators: Author of the plugin translators: Author of the plugin translators: Author of the plugin translators: Author of the plugin translators: Author of the plugin */
	__( 'AnalogWP', 'ang' ),

	// Reference: analogwp-templates.php:45
	// Reference: analogwp-templates.php:207
	// Reference: languages/ang-translations.php:37
	/* translators: translators: %s: version number
translators: translators: %s: version number translators: translators: %s: version number translators: translators: %s: version number translators: translators: %s: version number translators: translators: %s: version number translators: translators: %s: version number translators: translators: %s: version number translators: translators: %s: version number translators: translators: %s: version number translators: translators: %s: version number translators: translators: %s: version number translators: translators: %s: version number translators: translators: %s: version number translators: translators: %s: version number translators: translators: %s: version number translators: translators: %s: version number translators: translators: %s: version number translators: translators: %s: version number translators: translators: %s: version number translators: translators: %s: version number translators: translators: %s: version number translators: translators: %s: version number translators: translators: %s: version number translators: translators: %s: version number translators: translators: %s: version number translators: translators: %s: version number translators: translators: %s: version number translators: translators: %s: version number translators: translators: %s: version number translators: translators: %s: version number translators: translators: %s: version number translators: translators: %s: version number translators: translators: %s: version number translators: translators: %s: version number translators: translators: %s: version number */
	__( 'Style Kit for Elementor requires PHP version %s', 'ang' ),

	// Reference: analogwp-templates.php:46
	// Reference: analogwp-templates.php:208
	// Reference: languages/ang-translations.php:42
	__( 'Error Activating', 'ang' ),

	// Reference: analogwp-templates.php:80
	// Reference: languages/ang-translations.php:48
	/* translators: translators: %s: WordPress version
translators: translators: %s: WordPress version translators: translators: %s: WordPress version translators: translators: %s: WordPress version translators: translators: %s: WordPress version translators: translators: %s: WordPress version translators: translators: %s: WordPress version translators: translators: %s: WordPress version translators: translators: %s: WordPress version translators: translators: %s: WordPress version translators: translators: %s: WordPress version translators: translators: %s: WordPress version translators: translators: %s: WordPress version translators: translators: %s: WordPress version translators: translators: %s: WordPress version translators: translators: %s: WordPress version translators: translators: %s: WordPress version translators: translators: %s: WordPress version translators: translators: %s: WordPress version translators: translators: %s: WordPress version translators: translators: %s: WordPress version translators: translators: %s: WordPress version translators: translators: %s: WordPress version translators: translators: %s: WordPress version translators: translators: %s: WordPress version translators: translators: %s: WordPress version translators: translators: %s: WordPress version translators: translators: %s: WordPress version translators: translators: %s: WordPress version translators: translators: %s: WordPress version translators: translators: %s: WordPress version translators: translators: %s: WordPress version translators: translators: %s: WordPress version translators: translators: %s: WordPress version translators: translators: %s: WordPress version translators: translators: %s: WordPress version */
	__( 'Style Kits requires WordPress version %s+. Because you are using an earlier version, the plugin is currently NOT RUNNING.', 'ang' ),

	// Reference: analogwp-templates.php:103
	// Reference: languages/ang-translations.php:54
	/* translators: translators: %s: Minimum required Elementor version.
translators: translators: %s: Minimum required Elementor version. translators: translators: %s: Minimum required Elementor version. translators: translators: %s: Minimum required Elementor version. translators: translators: %s: Minimum required Elementor version. translators: translators: %s: Minimum required Elementor version. translators: translators: %s: Minimum required Elementor version. translators: translators: %s: Minimum required Elementor version. translators: translators: %s: Minimum required Elementor version. translators: translators: %s: Minimum required Elementor version. translators: translators: %s: Minimum required Elementor version. translators: translators: %s: Minimum required Elementor version. translators: translators: %s: Minimum required Elementor version. translators: translators: %s: Minimum required Elementor version. translators: translators: %s: Minimum required Elementor version. translators: translators: %s: Minimum required Elementor version. translators: translators: %s: Minimum required Elementor version. translators: translators: %s: Minimum required Elementor version. translators: translators: %s: Minimum required Elementor version. translators: translators: %s: Minimum required Elementor version. translators: translators: %s: Minimum required Elementor version. translators: translators: %s: Minimum required Elementor version. translators: translators: %s: Minimum required Elementor version. translators: translators: %s: Minimum required Elementor version. translators: translators: %s: Minimum required Elementor version. translators: translators: %s: Minimum required Elementor version. translators: translators: %s: Minimum required Elementor version. translators: translators: %s: Minimum required Elementor version. translators: translators: %s: Minimum required Elementor version. translators: translators: %s: Minimum required Elementor version. translators: translators: %s: Minimum required Elementor version. translators: translators: %s: Minimum required Elementor version. translators: translators: %s: Minimum required Elementor version. translators: translators: %s: Minimum required Elementor version. translators: translators: %s: Minimum required Elementor version. translators: translators: %s: Minimum required Elementor version. */
	__( 'Style Kits requires Elementor v%s or newer in order to work. Please update Elementor to the latest version.', 'ang' ),

	// Reference: analogwp-templates.php:109
	// Reference: languages/ang-translations.php:60
	/* translators: translators: %s: Link to update Elementor.
translators: translators: %s: Link to update Elementor. translators: translators: %s: Link to update Elementor. translators: translators: %s: Link to update Elementor. translators: translators: %s: Link to update Elementor. translators: translators: %s: Link to update Elementor. translators: translators: %s: Link to update Elementor. translators: translators: %s: Link to update Elementor. translators: translators: %s: Link to update Elementor. translators: translators: %s: Link to update Elementor. translators: translators: %s: Link to update Elementor. translators: translators: %s: Link to update Elementor. translators: translators: %s: Link to update Elementor. translators: translators: %s: Link to update Elementor. translators: translators: %s: Link to update Elementor. translators: translators: %s: Link to update Elementor. translators: translators: %s: Link to update Elementor. translators: translators: %s: Link to update Elementor. translators: translators: %s: Link to update Elementor. translators: translators: %s: Link to update Elementor. translators: translators: %s: Link to update Elementor. translators: translators: %s: Link to update Elementor. translators: translators: %s: Link to update Elementor. */
	__( 'Update Elementor Now', 'ang' ),

	// Reference: analogwp-templates.php:115
	// Reference: languages/ang-translations.php:66
	/* translators: translators: %s: Version number.
translators: translators: %s: Version number. translators: translators: %s: Version number. translators: translators: %s: Version number. translators: translators: %s: Version number. translators: translators: %s: Version number. translators: translators: %s: Version number. translators: translators: %s: Version number. translators: translators: %s: Version number. translators: translators: %s: Version number. translators: translators: %s: Version number. translators: translators: %s: Version number. translators: translators: %s: Version number. translators: translators: %s: Version number. translators: translators: %s: Version number. translators: translators: %s: Version number. translators: translators: %s: Version number. translators: translators: %s: Version number. translators: translators: %s: Version number. translators: translators: %s: Version number. translators: translators: %s: Version number. translators: translators: %s: Version number. translators: translators: %s: Version number. */
	__( 'Rollback to v%s', 'ang' ),

	// Reference: analogwp-templates.php:148
	// Reference: languages/ang-translations.php:70
	__( 'An error occurred while checking Elementor is Installed/Activated', 'ang' ),

	// Reference: analogwp-templates.php:181
	// Reference: languages/ang-translations.php:74
	__( 'Style Kits is not working because you need to activate the Elementor plugin.', 'ang' ),

	// Reference: analogwp-templates.php:182
	// Reference: languages/ang-translations.php:78
	__( 'Activate Elementor Now', 'ang' ),

	// Reference: analogwp-templates.php:189
	// Reference: languages/ang-translations.php:82
	__( 'Style Kits is not working because you need to install the Elementor plugin.', 'ang' ),

	// Reference: analogwp-templates.php:190
	// Reference: languages/ang-translations.php:86
	__( 'Install Elementor Now', 'ang' ),

	// Reference: inc/admin/class-admin.php:43
	// Reference: languages/ang-translations.php:92
	/* translators: translators: 1: Style Kits for Elementor, 2: Link to plugin review
translators: translators: 1: Style Kits for Elementor, 2: Link to plugin review translators: translators: 1: Style Kits for Elementor, 2: Link to plugin review translators: translators: 1: Style Kits for Elementor, 2: Link to plugin review translators: translators: 1: Style Kits for Elementor, 2: Link to plugin review translators: translators: 1: Style Kits for Elementor, 2: Link to plugin review translators: translators: 1: Style Kits for Elementor, 2: Link to plugin review translators: translators: 1: Style Kits for Elementor, 2: Link to plugin review translators: translators: 1: Style Kits for Elementor, 2: Link to plugin review translators: translators: 1: Style Kits for Elementor, 2: Link to plugin review translators: translators: 1: Style Kits for Elementor, 2: Link to plugin review translators: translators: 1: Style Kits for Elementor, 2: Link to plugin review translators: translators: 1: Style Kits for Elementor, 2: Link to plugin review translators: translators: 1: Style Kits for Elementor, 2: Link to plugin review translators: translators: 1: Style Kits for Elementor, 2: Link to plugin review translators: translators: 1: Style Kits for Elementor, 2: Link to plugin review translators: translators: 1: Style Kits for Elementor, 2: Link to plugin review translators: translators: 1: Style Kits for Elementor, 2: Link to plugin review translators: translators: 1: Style Kits for Elementor, 2: Link to plugin review translators: translators: 1: Style Kits for Elementor, 2: Link to plugin review translators: translators: 1: Style Kits for Elementor, 2: Link to plugin review translators: translators: 1: Style Kits for Elementor, 2: Link to plugin review translators: translators: 1: Style Kits for Elementor, 2: Link to plugin review translators: translators: 1: Style Kits for Elementor, 2: Link to plugin review translators: translators: 1: Style Kits for Elementor, 2: Link to plugin review translators: translators: 1: Style Kits for Elementor, 2: Link to plugin review translators: translators: 1: Style Kits for Elementor, 2: Link to plugin review translators: translators: 1: Style Kits for Elementor, 2: Link to plugin review translators: translators: 1: Style Kits for Elementor, 2: Link to plugin review translators: translators: 1: Style Kits for Elementor, 2: Link to plugin review translators: translators: 1: Style Kits for Elementor, 2: Link to plugin review translators: translators: 1: Style Kits for Elementor, 2: Link to plugin review translators: translators: 1: Style Kits for Elementor, 2: Link to plugin review translators: translators: 1: Style Kits for Elementor, 2: Link to plugin review translators: translators: 1: Style Kits for Elementor, 2: Link to plugin review translators: translators: 1: Style Kits for Elementor, 2: Link to plugin review */
	__( 'Enjoyed %1$s? Please leave us a %2$s rating. We really appreciate your support!', 'ang' ),

	// Reference: inc/admin/class-admin.php:65
	// Reference: languages/ang-translations.php:96
	__( 'View Documentation', 'ang' ),

	// Reference: inc/admin/class-admin.php:65
	// Reference: inc/settings/views/html-admin-settings.php:97
	// Reference: languages/ang-translations.php:101
	__( 'Documentation', 'ang' ),

	// Reference: inc/admin/class-admin.php:66
	// Reference: languages/ang-translations.php:105
	__( 'Get Support', 'ang' ),

	// Reference: inc/admin/Notice.php:172
	// Reference: languages/ang-translations.php:109
	__( 'Style Kits for Elementor Logo', 'ang' ),

	// Reference: inc/api/class-local.php:127
	// Reference: inc/api/class-local.php:320
	// Reference: languages/ang-translations.php:114
	__( 'Invalid or expired license provided.', 'ang' ),

	// Reference: inc/api/class-local.php:393
	// Reference: languages/ang-translations.php:118
	__( 'Setting updated.', 'ang' ),

	// Reference: inc/api/class-local.php:452
	// Reference: languages/ang-translations.php:122
	__( 'Invalid param(s).', 'ang' ),

	// Reference: inc/api/class-local.php:456
	// Reference: languages/ang-translations.php:126
	__( 'Please provide a title.', 'ang' ),

	// Reference: inc/api/class-local.php:473
	// Reference: languages/ang-translations.php:130
	__( 'Unable to create a Kit', 'ang' ),

	// Reference: inc/api/class-local.php:479
	// Reference: languages/ang-translations.php:134
	__( 'The new Theme Style Kit has been saved and applied on this page.', 'ang' ),

	// Reference: inc/api/class-local.php:496
	// Reference: inc/api/class-local.php:526
	// Reference: languages/ang-translations.php:139
	__( 'Please provide a valid post ID.', 'ang' ),

	// Reference: inc/api/class-local.php:500
	// Reference: languages/ang-translations.php:143
	__( 'Invalid Post ID', 'ang' ),

	// Reference: inc/api/class-local.php:553
	// Reference: languages/ang-translations.php:147
	__( 'Invalid Style Kit ID.', 'ang' ),

	// Reference: inc/api/class-local.php:583
	// Reference: languages/ang-translations.php:151
	__( 'Error occured while requesting Style Kit data.', 'ang' ),

	// Reference: inc/api/class-local.php:613
	// Reference: languages/ang-translations.php:155
	__( 'Style Kit imported', 'ang' ),

	// Reference: inc/api/class-local.php:648
	// Reference: languages/ang-translations.php:159
	__( 'Invalid token data returned', 'ang' ),

	// Reference: inc/api/class-local.php:666
	// Reference: languages/ang-translations.php:163
	__( 'Invalid Block ID.', 'ang' ),

	// Reference: inc/class-admin-settings.php:76
	// Reference: languages/ang-translations.php:167
	__( 'Your settings have been saved.', 'ang' ),

	// Reference: inc/class-admin-settings.php:133
	// Reference: languages/ang-translations.php:171
	__( 'The changes you made will be lost if you navigate away from this page.', 'ang' ),

	// Reference: inc/class-admin-settings.php:550
	// Reference: inc/class-admin-settings.php:615
	// Reference: languages/ang-translations.php:176
	__( 'Toggle', 'ang' ),

	// Reference: inc/class-base.php:39
	// Reference: inc/class-base.php:49
	// Reference: languages/ang-translations.php:181
	__( 'Something went wrong.', 'ang' ),

	// Reference: inc/class-cron.php:41
	// Reference: languages/ang-translations.php:185
	__( 'Once Weekly', 'ang' ),

	// Reference: inc/class-elementor.php:48
	// Reference: languages/ang-translations.php:189
	__( 'AnalogWP Classes', 'ang' ),

	// Reference: inc/class-quick-edit.php:83
	// Reference: inc/class-quick-edit.php:137
	// Reference: inc/elementor/class-post-type.php:33
	// Reference: languages/ang-translations.php:195
	__( 'Style Kit', 'ang' ),

	// Reference: inc/class-tracker.php:130
	// Reference: languages/ang-translations.php:201
	/* translators: translators: %2$s Plugin Name %3%s Review text
translators: translators: %2$s Plugin Name %3%s Review text translators: translators: %2$s Plugin Name %3%s Review text translators: translators: %2$s Plugin Name %3%s Review text translators: translators: %2$s Plugin Name %3%s Review text translators: translators: %2$s Plugin Name %3%s Review text translators: translators: %2$s Plugin Name %3%s Review text translators: translators: %2$s Plugin Name %3%s Review text translators: translators: %2$s Plugin Name %3%s Review text translators: translators: %2$s Plugin Name %3%s Review text translators: translators: %2$s Plugin Name %3%s Review text translators: translators: %2$s Plugin Name %3%s Review text translators: translators: %2$s Plugin Name %3%s Review text translators: translators: %2$s Plugin Name %3%s Review text translators: translators: %2$s Plugin Name %3%s Review text translators: translators: %2$s Plugin Name %3%s Review text translators: translators: %2$s Plugin Name %3%s Review text translators: translators: %2$s Plugin Name %3%s Review text translators: translators: %2$s Plugin Name %3%s Review text translators: translators: %2$s Plugin Name %3%s Review text translators: translators: %2$s Plugin Name %3%s Review text translators: translators: %2$s Plugin Name %3%s Review text translators: translators: %2$s Plugin Name %3%s Review text translators: translators: %2$s Plugin Name %3%s Review text translators: translators: %2$s Plugin Name %3%s Review text translators: translators: %2$s Plugin Name %3%s Review text translators: translators: %2$s Plugin Name %3%s Review text translators: translators: %2$s Plugin Name %3%s Review text translators: translators: %2$s Plugin Name %3%s Review text translators: translators: %2$s Plugin Name %3%s Review text translators: translators: %2$s Plugin Name %3%s Review text translators: translators: %2$s Plugin Name %3%s Review text translators: translators: %2$s Plugin Name %3%s Review text translators: translators: %2$s Plugin Name %3%s Review text translators: translators: %2$s Plugin Name %3%s Review text translators: translators: %2$s Plugin Name %3%s Review text */
	__( 'Hey! You have been using %1$s for over 2 weeks, we hope you enjoy it! If so, please leave a positive %2$s.', 'ang' ),

	// Reference: inc/class-tracker.php:132
	// Reference: languages/ang-translations.php:205
	__( 'review on WordPress.org', 'ang' ),

	// Reference: inc/elementor/class-ang-action.php:100
	// Reference: languages/ang-translations.php:209
	__( 'This will clean-up all the values from the current Theme Style kit. If you need to revert, you can do so at the Revisions tab.', 'ang' ),

	// Reference: inc/elementor/class-ang-action.php:101
	// Reference: languages/ang-translations.php:213
	__( 'Are you sure?', 'ang' ),

	// Reference: inc/elementor/class-ang-action.php:102
	// Reference: languages/ang-translations.php:217
	__( 'Save Style Kit as', 'ang' ),

	// Reference: inc/elementor/class-ang-action.php:103
	// Reference: languages/ang-translations.php:221
	__( 'Save', 'ang' ),

	// Reference: inc/elementor/class-ang-action.php:104
	// Reference: languages/ang-translations.php:225
	__( 'Cancel', 'ang' ),

	// Reference: inc/elementor/class-ang-action.php:105
	// Reference: languages/ang-translations.php:229
	__( 'Enter a title', 'ang' ),

	// Reference: inc/elementor/class-ang-action.php:106
	// Reference: languages/ang-translations.php:233
	__( 'Insert Style Kit', 'ang' ),

	// Reference: inc/elementor/class-ang-action.php:107
	// Reference: inc/elementor/class-ang-action.php:110
	// Reference: languages/ang-translations.php:238
	__( 'Please select a Style Kit first.', 'ang' ),

	// Reference: inc/elementor/class-ang-action.php:108
	// Reference: languages/ang-translations.php:242
	__( '— Select a Style Kit —', 'ang' ),

	// Reference: inc/elementor/class-ang-action.php:109
	// Reference: languages/ang-translations.php:246
	__( 'Style Kit Updated.', 'ang' ),

	// Reference: inc/elementor/class-ang-action.php:111
	// Reference: languages/ang-translations.php:250
	__( 'Update Style Kit', 'ang' ),

	// Reference: inc/elementor/class-ang-action.php:112
	// Reference: languages/ang-translations.php:254
	__( 'This action will update the Style Kit with the latest changes, and will affect all the pages that the style kit is used on. Do you wish to proceed?', 'ang' ),

	// Reference: inc/elementor/class-ang-action.php:113
	// Reference: languages/ang-translations.php:258
	__( 'Meet Style Kits for Elementor', 'ang' ),

	// Reference: inc/elementor/class-ang-action.php:116
	// Reference: languages/ang-translations.php:264
	/* translators: translators: %s: Link to Style Kits documentation.
translators: translators: %s: Link to Style Kits documentation. translators: translators: %s: Link to Style Kits documentation. translators: translators: %s: Link to Style Kits documentation. translators: translators: %s: Link to Style Kits documentation. translators: translators: %s: Link to Style Kits documentation. translators: translators: %s: Link to Style Kits documentation. translators: translators: %s: Link to Style Kits documentation. translators: translators: %s: Link to Style Kits documentation. translators: translators: %s: Link to Style Kits documentation. translators: translators: %s: Link to Style Kits documentation. translators: translators: %s: Link to Style Kits documentation. translators: translators: %s: Link to Style Kits documentation. translators: translators: %s: Link to Style Kits documentation. translators: translators: %s: Link to Style Kits documentation. translators: translators: %s: Link to Style Kits documentation. translators: translators: %s: Link to Style Kits documentation. translators: translators: %s: Link to Style Kits documentation. translators: translators: %s: Link to Style Kits documentation. translators: translators: %s: Link to Style Kits documentation. translators: translators: %s: Link to Style Kits documentation. translators: translators: %s: Link to Style Kits documentation. translators: translators: %s: Link to Style Kits documentation. translators: translators: %s: Link to Style Kits documentation. translators: translators: %s: Link to Style Kits documentation. translators: translators: %s: Link to Style Kits documentation. translators: translators: %s: Link to Style Kits documentation. translators: translators: %s: Link to Style Kits documentation. translators: translators: %s: Link to Style Kits documentation. translators: translators: %s: Link to Style Kits documentation. translators: translators: %s: Link to Style Kits documentation. translators: translators: %s: Link to Style Kits documentation. translators: translators: %s: Link to Style Kits documentation. translators: translators: %s: Link to Style Kits documentation. translators: translators: %s: Link to Style Kits documentation. translators: translators: %s: Link to Style Kits documentation. */
	__( 'Take control of your design in the macro level, with local or global settings for typography and spacing. %s.', 'ang' ),

	// Reference: inc/elementor/class-ang-action.php:118
	// Reference: languages/ang-translations.php:270
	/* translators: translators: %s: Link text
translators: translators: %s: Link text translators: translators: %s: Link text translators: translators: %s: Link text translators: translators: %s: Link text translators: translators: %s: Link text translators: translators: %s: Link text translators: translators: %s: Link text translators: translators: %s: Link text translators: translators: %s: Link text translators: translators: %s: Link text translators: translators: %s: Link text translators: translators: %s: Link text translators: translators: %s: Link text translators: translators: %s: Link text translators: translators: %s: Link text translators: translators: %s: Link text translators: translators: %s: Link text translators: translators: %s: Link text translators: translators: %s: Link text translators: translators: %s: Link text translators: translators: %s: Link text translators: translators: %s: Link text translators: translators: %s: Link text translators: translators: %s: Link text translators: translators: %s: Link text translators: translators: %s: Link text translators: translators: %s: Link text translators: translators: %s: Link text translators: translators: %s: Link text translators: translators: %s: Link text translators: translators: %s: Link text translators: translators: %s: Link text translators: translators: %s: Link text translators: translators: %s: Link text translators: translators: %s: Link text */
	__( 'Learn more', 'ang' ),

	// Reference: inc/elementor/class-ang-action.php:120
	// Reference: languages/ang-translations.php:274
	__( 'View Styles', 'ang' ),

	// Reference: inc/elementor/class-ang-action.php:121
	// Reference: inc/elementor/class-post-type.php:32
	// Reference: inc/elementor/class-post-type.php:41
	// Reference: inc/elementor/class-typography.php:683
	// Reference: inc/elementor/kit/Kits_List_Table.php:309
	// Reference: inc/elementor/kit/tabs/Theme_Style_Kits.php:46
	// Reference: inc/register-settings.php:27
	// Reference: inc/register-settings.php:56
	// Reference: languages/ang-translations.php:285
	__( 'Style Kits', 'ang' ),

	// Reference: inc/elementor/class-ang-action.php:122
	// Reference: languages/ang-translations.php:289
	__( 'Export CSS', 'ang' ),

	// Reference: inc/elementor/class-ang-action.php:123
	// Reference: languages/ang-translations.php:293
	__( 'Copy CSS', 'ang' ),

	// Reference: inc/elementor/class-ang-action.php:124
	// Reference: languages/ang-translations.php:297
	__( 'Style Kit Update Detected', 'ang' ),

	// Reference: inc/elementor/class-ang-action.php:125
	// Reference: languages/ang-translations.php:301
	__( '<p>The Style kit used by this page has been updated, click ‘Apply Changes’ to apply the latest changes.</p><p>Click Discard to keep your current page styles and detach the page from the Style Kit</p>', 'ang' ),

	// Reference: inc/elementor/class-ang-action.php:126
	// Reference: languages/ang-translations.php:305
	__( 'Discard', 'ang' ),

	// Reference: inc/elementor/class-ang-action.php:127
	// Reference: languages/ang-translations.php:309
	__( 'Apply Changes', 'ang' ),

	// Reference: inc/elementor/class-ang-action.php:128
	// Reference: languages/ang-translations.php:313
	__( 'Ok, got it.', 'ang' ),

	// Reference: inc/elementor/class-ang-action.php:129
	// Reference: languages/ang-translations.php:317
	__( 'Go to Page Style', 'ang' ),

	// Reference: inc/elementor/class-ang-action.php:130
	// Reference: languages/ang-translations.php:321
	__( 'This template offers global typography and spacing control, through the Page Style tab.', 'ang' ),

	// Reference: inc/elementor/class-ang-action.php:131
	// Reference: languages/ang-translations.php:325
	__( 'Typography, column gaps and more, are controlled layout-wide at Page Styles Panel, giving you the flexibility you need over the design of this template. You can save the styles and apply them to any other page. <a href="#" target="_blank">Learn More.</a>', 'ang' ),

	// Reference: inc/elementor/class-ang-action.php:132
	// Reference: languages/ang-translations.php:329
	__( 'CSS Variables', 'ang' ),

	// Reference: inc/elementor/class-ang-action.php:133
	// Reference: languages/ang-translations.php:333
	__( 'Remove Page ID from the CSS', 'ang' ),

	// Reference: inc/elementor/class-colors.php:163
	// Reference: languages/ang-translations.php:339
	/* translators: translators: %1$s: Link to documentation, %2$s: Link text.
translators: translators: %1$s: Link to documentation, %2$s: Link text. translators: translators: %1$s: Link to documentation, %2$s: Link text. translators: translators: %1$s: Link to documentation, %2$s: Link text. translators: translators: %1$s: Link to documentation, %2$s: Link text. translators: translators: %1$s: Link to documentation, %2$s: Link text. translators: translators: %1$s: Link to documentation, %2$s: Link text. translators: translators: %1$s: Link to documentation, %2$s: Link text. translators: translators: %1$s: Link to documentation, %2$s: Link text. translators: translators: %1$s: Link to documentation, %2$s: Link text. translators: translators: %1$s: Link to documentation, %2$s: Link text. translators: translators: %1$s: Link to documentation, %2$s: Link text. translators: translators: %1$s: Link to documentation, %2$s: Link text. translators: translators: %1$s: Link to documentation, %2$s: Link text. translators: translators: %1$s: Link to documentation, %2$s: Link text. translators: translators: %1$s: Link to documentation, %2$s: Link text. translators: translators: %1$s: Link to documentation, %2$s: Link text. translators: translators: %1$s: Link to documentation, %2$s: Link text. translators: translators: %1$s: Link to documentation, %2$s: Link text. translators: translators: %1$s: Link to documentation, %2$s: Link text. translators: translators: %1$s: Link to documentation, %2$s: Link text. translators: translators: %1$s: Link to documentation, %2$s: Link text. translators: translators: %1$s: Link to documentation, %2$s: Link text. translators: translators: %1$s: Link to documentation, %2$s: Link text. translators: translators: %1$s: Link to documentation, %2$s: Link text. translators: translators: %1$s: Link to documentation, %2$s: Link text. translators: translators: %1$s: Link to documentation, %2$s: Link text. translators: translators: %1$s: Link to documentation, %2$s: Link text. translators: translators: %1$s: Link to documentation, %2$s: Link text. translators: translators: %1$s: Link to documentation, %2$s: Link text. translators: translators: %1$s: Link to documentation, %2$s: Link text. translators: translators: %1$s: Link to documentation, %2$s: Link text. translators: translators: %1$s: Link to documentation, %2$s: Link text. translators: translators: %1$s: Link to documentation, %2$s: Link text. translators: translators: %1$s: Link to documentation, %2$s: Link text. translators: translators: %1$s: Link to documentation, %2$s: Link text. */
	__( 'Set the accent colors of your layout.', 'ang' ),

	// Reference: inc/elementor/class-colors.php:163
	// Reference: inc/elementor/class-typography.php:263
	// Reference: inc/elementor/class-typography.php:312
	// Reference: inc/elementor/class-typography.php:373
	// Reference: inc/elementor/class-typography.php:426
	// Reference: inc/elementor/class-typography.php:481
	// Reference: languages/ang-translations.php:350
	/* translators: translators: %1$s: Link to documentation, %2$s: Link text.
translators: translators: %1$s: Link to documentation, %2$s: Link text. translators: translators: %1$s: Link to documentation, %2$s: Link text. translators: translators: %1$s: Link to documentation, %2$s: Link text. translators: translators: %1$s: Link to documentation, %2$s: Link text. translators: translators: %1$s: Link to documentation, %2$s: Link text. translators: translators: %1$s: Link to documentation, %2$s: Link text. translators: translators: %1$s: Link to documentation, %2$s: Link text. translators: translators: %1$s: Link to documentation, %2$s: Link text. translators: translators: %1$s: Link to documentation, %2$s: Link text. translators: translators: %1$s: Link to documentation, %2$s: Link text. translators: translators: %1$s: Link to documentation, %2$s: Link text. translators: translators: %1$s: Link to documentation, %2$s: Link text. translators: translators: %1$s: Link to documentation, %2$s: Link text. translators: translators: %1$s: Link to documentation, %2$s: Link text. translators: translators: %1$s: Link to documentation, %2$s: Link text. translators: translators: %1$s: Link to documentation, %2$s: Link text. translators: translators: %1$s: Link to documentation, %2$s: Link text. translators: translators: %1$s: Link to documentation, %2$s: Link text. translators: translators: %1$s: Link to documentation, %2$s: Link text. translators: translators: %1$s: Link to documentation, %2$s: Link text. translators: translators: %1$s: Link to documentation, %2$s: Link text. translators: translators: %1$s: Link to documentation, %2$s: Link text. translators: translators: %1$s: Link to documentation, %2$s: Link text. translators: translators: %1$s: Link to documentation, %2$s: Link text. translators: translators: %1$s: Link to documentation, %2$s: Link text. translators: translators: %1$s: Link to documentation, %2$s: Link text. translators: translators: %1$s: Link to documentation, %2$s: Link text. translators: translators: %1$s: Link to documentation, %2$s: Link text. translators: translators: %1$s: Link to documentation, %2$s: Link text. translators: translators: %1$s: Link to documentation, %2$s: Link text. translators: translators: %1$s: Link to documentation, %2$s: Link text. translators: translators: %1$s: Link to documentation, %2$s: Link text. translators: translators: %1$s: Link to documentation, %2$s: Link text. translators: translators: %1$s: Link to documentation, %2$s: Link text. translators: translators: %1$s: Link to documentation, %2$s: Link text. */
	__( 'Learn more.', 'ang' ),

	// Reference: inc/elementor/class-colors.php:230
	// Reference: languages/ang-translations.php:354
	__( 'The primary accent color applies on links, icons, and other elements. You can also define the text link color in the Typography panel.', 'ang' ),

	// Reference: inc/elementor/class-colors.php:234
	// Reference: languages/ang-translations.php:358
	__( 'Primary Accent', 'ang' ),

	// Reference: inc/elementor/class-colors.php:253
	// Reference: languages/ang-translations.php:362
	__( 'The default button color. You can also define button colors under the Buttons panel, and individually for each button size under Buttons Sizes panel.', 'ang' ),

	// Reference: inc/elementor/class-colors.php:257
	// Reference: languages/ang-translations.php:366
	__( 'Secondary Accent', 'ang' ),

	// Reference: inc/elementor/class-finder-shortcuts.php:23
	// Reference: languages/ang-translations.php:370
	__( 'Style Kits for Elementor Shortcuts', 'ang' ),

	// Reference: inc/elementor/class-finder-shortcuts.php:36
	// Reference: languages/ang-translations.php:374
	__( 'Templates Library', 'ang' ),

	// Reference: inc/elementor/class-finder-shortcuts.php:42
	// Reference: inc/elementor/kit/Manager.php:307
	// Reference: inc/Plugin.php:196
	// Reference: inc/register-settings.php:46
	// Reference: languages/ang-translations.php:381
	__( 'Settings', 'ang' ),

	// Reference: inc/elementor/class-finder-shortcuts.php:48
	// Reference: inc/register-settings.php:57
	// Reference: languages/ang-translations.php:386
	__( 'Theme Style Kits', 'ang' ),

	// Reference: inc/elementor/class-post-type.php:37
	// Reference: languages/ang-translations.php:390
	__( 'Add New Style Kit', 'ang' ),

	// Reference: inc/elementor/class-post-type.php:38
	// Reference: languages/ang-translations.php:394
	__( 'New Style Kit', 'ang' ),

	// Reference: inc/elementor/class-post-type.php:39
	// Reference: languages/ang-translations.php:398
	__( 'Edit Style Kit', 'ang' ),

	// Reference: inc/elementor/class-post-type.php:40
	// Reference: languages/ang-translations.php:402
	__( 'View Style Kit', 'ang' ),

	// Reference: inc/elementor/class-post-type.php:42
	// Reference: languages/ang-translations.php:406
	__( 'Search Style Kits', 'ang' ),

	// Reference: inc/elementor/class-post-type.php:43
	// Reference: languages/ang-translations.php:410
	__( 'Parent Style Kits:', 'ang' ),

	// Reference: inc/elementor/class-post-type.php:44
	// Reference: languages/ang-translations.php:414
	__( 'No Style Kit found.', 'ang' ),

	// Reference: inc/elementor/class-post-type.php:45
	// Reference: languages/ang-translations.php:418
	__( 'No Style Kit found in Trash.', 'ang' ),

	// Reference: inc/elementor/class-tools.php:119
	// Reference: languages/ang-translations.php:422
	__( 'Error occurred, the version selected is invalid. Try selecting different version.', 'ang' ),

	// Reference: inc/elementor/class-tools.php:163
	// Reference: languages/ang-translations.php:426
	__( 'Rollback to Previous Version', 'ang' ),

	// Reference: inc/elementor/class-tools.php:227
	// Reference: languages/ang-translations.php:432
	/* translators: translators: %s: Style kit title.
translators: translators: %s: Style kit title. translators: translators: %s: Style kit title. translators: translators: %s: Style kit title. translators: translators: %s: Style kit title. translators: translators: %s: Style kit title. translators: translators: %s: Style kit title. translators: translators: %s: Style kit title. translators: translators: %s: Style kit title. translators: translators: %s: Style kit title. translators: translators: %s: Style kit title. translators: translators: %s: Style kit title. translators: translators: %s: Style kit title. translators: translators: %s: Style kit title. translators: translators: %s: Style kit title. translators: translators: %s: Style kit title. translators: translators: %s: Style kit title. translators: translators: %s: Style kit title. translators: translators: %s: Style kit title. translators: translators: %s: Style kit title. translators: translators: %s: Style kit title. translators: translators: %s: Style kit title. translators: translators: %s: Style kit title. translators: translators: %s: Style kit title. translators: translators: %s: Style kit title. translators: translators: %s: Style kit title. translators: translators: %s: Style kit title. translators: translators: %s: Style kit title. translators: translators: %s: Style kit title. translators: translators: %s: Style kit title. translators: translators: %s: Style kit title. translators: translators: %s: Style kit title. translators: translators: %s: Style kit title. translators: translators: %s: Style kit title. translators: translators: %s: Style kit title. translators: translators: %s: Style kit title. */
	__( 'Style Kit: %s <span style="color:#5C32B6;">&#9679;</span>', 'ang' ),

	// Reference: inc/elementor/class-tools.php:261
	// Reference: languages/ang-translations.php:436
	__( 'Apply Global Style Kit', 'ang' ),

	// Reference: inc/elementor/class-tools.php:307
	// Reference: languages/ang-translations.php:440
	__( 'Invalid/empty Post ID.', 'ang' ),

	// Reference: inc/elementor/class-typography.php:142
	// Reference: languages/ang-translations.php:444
	__( 'Headings Typography', 'ang' ),

	// Reference: inc/elementor/class-typography.php:150
	// Reference: languages/ang-translations.php:448
	__( 'These settings apply to all Headings in your layout. You can still override individual values at each element.', 'ang' ),

	// Reference: inc/elementor/class-typography.php:174
	// Reference: languages/ang-translations.php:454
	/* translators: translators: %s: Heading 1-6 type
translators: translators: %s: Heading 1-6 type translators: translators: %s: Heading 1-6 type translators: translators: %s: Heading 1-6 type translators: translators: %s: Heading 1-6 type translators: translators: %s: Heading 1-6 type translators: translators: %s: Heading 1-6 type translators: translators: %s: Heading 1-6 type translators: translators: %s: Heading 1-6 type translators: translators: %s: Heading 1-6 type translators: translators: %s: Heading 1-6 type translators: translators: %s: Heading 1-6 type translators: translators: %s: Heading 1-6 type translators: translators: %s: Heading 1-6 type translators: translators: %s: Heading 1-6 type translators: translators: %s: Heading 1-6 type translators: translators: %s: Heading 1-6 type translators: translators: %s: Heading 1-6 type translators: translators: %s: Heading 1-6 type translators: translators: %s: Heading 1-6 type translators: translators: %s: Heading 1-6 type translators: translators: %s: Heading 1-6 type translators: translators: %s: Heading 1-6 type translators: translators: %s: Heading 1-6 type translators: translators: %s: Heading 1-6 type translators: translators: %s: Heading 1-6 type translators: translators: %s: Heading 1-6 type translators: translators: %s: Heading 1-6 type translators: translators: %s: Heading 1-6 type translators: translators: %s: Heading 1-6 type translators: translators: %s: Heading 1-6 type translators: translators: %s: Heading 1-6 type translators: translators: %s: Heading 1-6 type translators: translators: %s: Heading 1-6 type translators: translators: %s: Heading 1-6 type translators: translators: %s: Heading 1-6 type */
	__( 'Heading %s', 'ang' ),

	// Reference: inc/elementor/class-typography.php:198
	// Reference: inc/elementor/class-typography.php:220
	// Reference: languages/ang-translations.php:459
	__( 'Body Typography', 'ang' ),

	// Reference: inc/elementor/class-typography.php:206
	// Reference: languages/ang-translations.php:463
	__( 'Recently Imported', 'ang' ),

	// Reference: inc/elementor/class-typography.php:239
	// Reference: languages/ang-translations.php:467
	__( 'Typographic Sizes', 'ang' ),

	// Reference: inc/elementor/class-typography.php:256
	// Reference: languages/ang-translations.php:471
	__( 'Heading Sizes', 'ang' ),

	// Reference: inc/elementor/class-typography.php:263
	// Reference: languages/ang-translations.php:475
	__( 'Edit the available sizes for the Heading Element.', 'ang' ),

	// Reference: inc/elementor/class-typography.php:270
	// Reference: inc/elementor/class-typography.php:319
	// Reference: languages/ang-translations.php:480
	__( 'XXL', 'ang' ),

	// Reference: inc/elementor/class-typography.php:271
	// Reference: inc/elementor/class-typography.php:320
	// Reference: inc/elementor/class-typography.php:492
	// Reference: languages/ang-translations.php:486
	__( 'XL', 'ang' ),

	// Reference: inc/elementor/class-typography.php:272
	// Reference: inc/elementor/class-typography.php:321
	// Reference: inc/elementor/class-typography.php:358
	// Reference: inc/elementor/class-typography.php:847
	// Reference: languages/ang-translations.php:493
	__( 'Large', 'ang' ),

	// Reference: inc/elementor/class-typography.php:273
	// Reference: inc/elementor/class-typography.php:322
	// Reference: inc/elementor/class-typography.php:357
	// Reference: inc/elementor/class-typography.php:846
	// Reference: languages/ang-translations.php:500
	__( 'Medium', 'ang' ),

	// Reference: inc/elementor/class-typography.php:274
	// Reference: inc/elementor/class-typography.php:323
	// Reference: inc/elementor/class-typography.php:356
	// Reference: inc/elementor/class-typography.php:845
	// Reference: languages/ang-translations.php:507
	__( 'Small', 'ang' ),

	// Reference: inc/elementor/class-typography.php:292
	// Reference: languages/ang-translations.php:511
	__( 'Heading', 'ang' ),

	// Reference: inc/elementor/class-typography.php:305
	// Reference: languages/ang-translations.php:515
	__( 'Text Sizes', 'ang' ),

	// Reference: inc/elementor/class-typography.php:312
	// Reference: languages/ang-translations.php:519
	__( 'Edit the available sizes for the p, span, and div tags of the Heading Element.', 'ang' ),

	// Reference: inc/elementor/class-typography.php:331
	// Reference: languages/ang-translations.php:523
	__( 'Text', 'ang' ),

	// Reference: inc/elementor/class-typography.php:354
	// Reference: inc/elementor/class-typography.php:842
	// Reference: languages/ang-translations.php:528
	__( 'Default', 'ang' ),

	// Reference: inc/elementor/class-typography.php:355
	// Reference: inc/elementor/class-typography.php:844
	// Reference: languages/ang-translations.php:533
	__( 'Normal', 'ang' ),

	// Reference: inc/elementor/class-typography.php:359
	// Reference: inc/elementor/class-typography.php:848
	// Reference: languages/ang-translations.php:538
	__( 'Extra Large', 'ang' ),

	// Reference: inc/elementor/class-typography.php:365
	// Reference: inc/elementor/class-typography.php:836
	// Reference: languages/ang-translations.php:543
	__( 'Outer Section Padding', 'ang' ),

	// Reference: inc/elementor/class-typography.php:373
	// Reference: languages/ang-translations.php:547
	__( 'Add padding to the outer sections of your layouts by using these controls.', 'ang' ),

	// Reference: inc/elementor/class-typography.php:408
	// Reference: languages/ang-translations.php:551
	__( 'Default Padding', 'ang' ),

	// Reference: inc/elementor/class-typography.php:409
	// Reference: languages/ang-translations.php:555
	__( 'Narrow Padding', 'ang' ),

	// Reference: inc/elementor/class-typography.php:410
	// Reference: languages/ang-translations.php:559
	__( 'Extended Padding', 'ang' ),

	// Reference: inc/elementor/class-typography.php:411
	// Reference: languages/ang-translations.php:563
	__( 'Wide Padding', 'ang' ),

	// Reference: inc/elementor/class-typography.php:412
	// Reference: languages/ang-translations.php:567
	__( 'Wider Padding', 'ang' ),

	// Reference: inc/elementor/class-typography.php:418
	// Reference: languages/ang-translations.php:571
	__( 'Column Gaps', 'ang' ),

	// Reference: inc/elementor/class-typography.php:426
	// Reference: languages/ang-translations.php:575
	__( 'Column Gap presets add padding to the columns of a section.', 'ang' ),

	// Reference: inc/elementor/class-typography.php:450
	// Reference: languages/ang-translations.php:579
	__( 'Space Between Widgets', 'ang' ),

	// Reference: inc/elementor/class-typography.php:451
	// Reference: languages/ang-translations.php:583
	__( 'Sets the default space between widgets, overrides the default value set in Elementor > Style > Space Between Widgets.', 'ang' ),

	// Reference: inc/elementor/class-typography.php:473
	// Reference: languages/ang-translations.php:587
	__( 'Button Sizes', 'ang' ),

	// Reference: inc/elementor/class-typography.php:481
	// Reference: languages/ang-translations.php:591
	__( 'Define the default styles for every button size.', 'ang' ),

	// Reference: inc/elementor/class-typography.php:488
	// Reference: languages/ang-translations.php:595
	__( 'XS', 'ang' ),

	// Reference: inc/elementor/class-typography.php:489
	// Reference: languages/ang-translations.php:599
	__( 'S', 'ang' ),

	// Reference: inc/elementor/class-typography.php:490
	// Reference: languages/ang-translations.php:603
	__( 'M', 'ang' ),

	// Reference: inc/elementor/class-typography.php:491
	// Reference: languages/ang-translations.php:607
	__( 'L', 'ang' ),

	// Reference: inc/elementor/class-typography.php:504
	// Reference: languages/ang-translations.php:611
	__( 'Typography', 'ang' ),

	// Reference: inc/elementor/class-typography.php:521
	// Reference: languages/ang-translations.php:615
	__( 'Normal Styling', 'ang' ),

	// Reference: inc/elementor/class-typography.php:529
	// Reference: inc/elementor/class-typography.php:588
	// Reference: inc/elementor/sections/background-color-classes.php:90
	// Reference: inc/elementor/sections/background-color-classes.php:176
	// Reference: languages/ang-translations.php:622
	__( 'Text Color', 'ang' ),

	// Reference: inc/elementor/class-typography.php:540
	// Reference: inc/elementor/class-typography.php:599
	// Reference: inc/elementor/sections/background-color-classes.php:76
	// Reference: inc/elementor/sections/background-color-classes.php:162
	// Reference: languages/ang-translations.php:629
	__( 'Background Color', 'ang' ),

	// Reference: inc/elementor/class-typography.php:567
	// Reference: inc/elementor/class-typography.php:626
	// Reference: languages/ang-translations.php:634
	__( 'Border Radius', 'ang' ),

	// Reference: inc/elementor/class-typography.php:580
	// Reference: languages/ang-translations.php:638
	__( 'Hover Styling', 'ang' ),

	// Reference: inc/elementor/class-typography.php:639
	// Reference: languages/ang-translations.php:642
	__( 'Padding', 'ang' ),

	// Reference: inc/elementor/class-typography.php:703
	// Reference: languages/ang-translations.php:646
	__( 'You are editing the Global Style Kit.', 'ang' ),

	// Reference: inc/elementor/class-typography.php:712
	// Reference: languages/ang-translations.php:650
	__( 'A Style Kit is a saved configuration of Theme Styles, that you can optionally apply on any page. This will override the Global theme Styles for this page.', 'ang' ),

	// Reference: inc/elementor/class-typography.php:716
	// Reference: languages/ang-translations.php:654
	__( 'Page Style Kit', 'ang' ),

	// Reference: inc/elementor/class-typography.php:730
	// Reference: inc/elementor/class-typography.php:732
	// Reference: languages/ang-translations.php:659
	__( 'Edit Theme Style Kit', 'ang' ),

	// Reference: inc/elementor/class-typography.php:743
	// Reference: languages/ang-translations.php:665
	/* translators: translators: %s: Link to Style Kits
translators: translators: %s: Link to Style Kits translators: translators: %s: Link to Style Kits translators: translators: %s: Link to Style Kits translators: translators: %s: Link to Style Kits translators: translators: %s: Link to Style Kits translators: translators: %s: Link to Style Kits translators: translators: %s: Link to Style Kits translators: translators: %s: Link to Style Kits translators: translators: %s: Link to Style Kits translators: translators: %s: Link to Style Kits translators: translators: %s: Link to Style Kits translators: translators: %s: Link to Style Kits translators: translators: %s: Link to Style Kits translators: translators: %s: Link to Style Kits translators: translators: %s: Link to Style Kits translators: translators: %s: Link to Style Kits translators: translators: %s: Link to Style Kits translators: translators: %s: Link to Style Kits translators: translators: %s: Link to Style Kits translators: translators: %s: Link to Style Kits translators: translators: %s: Link to Style Kits translators: translators: %s: Link to Style Kits translators: translators: %s: Link to Style Kits translators: translators: %s: Link to Style Kits translators: translators: %s: Link to Style Kits translators: translators: %s: Link to Style Kits translators: translators: %s: Link to Style Kits translators: translators: %s: Link to Style Kits translators: translators: %s: Link to Style Kits translators: translators: %s: Link to Style Kits translators: translators: %s: Link to Style Kits translators: translators: %s: Link to Style Kits translators: translators: %s: Link to Style Kits translators: translators: %s: Link to Style Kits translators: translators: %s: Link to Style Kits */
	__( 'You can set a Global Style Kit <a href="%s" target="_blank">here</a>.', 'ang' ),

	// Reference: inc/elementor/class-typography.php:765
	// Reference: languages/ang-translations.php:669
	__( 'Theme Style Kit', 'ang' ),

	// Reference: inc/elementor/class-typography.php:770
	// Reference: languages/ang-translations.php:673
	__( 'This will reset the Theme Style Kit and clean up any values.', 'ang' ),

	// Reference: inc/elementor/class-typography.php:774
	// Reference: languages/ang-translations.php:677
	__( 'Reset Theme Style Kit', 'ang' ),

	// Reference: inc/elementor/class-typography.php:776
	// Reference: languages/ang-translations.php:681
	__( 'Reset', 'ang' ),

	// Reference: inc/elementor/class-typography.php:781
	// Reference: languages/ang-translations.php:685
	__( 'Save the current styles as a different Theme Style Kit. You can then apply it on other pages, or globally.', 'ang' ),

	// Reference: inc/elementor/class-typography.php:785
	// Reference: languages/ang-translations.php:689
	__( 'Save Theme Style Kit as', 'ang' ),

	// Reference: inc/elementor/class-typography.php:787
	// Reference: languages/ang-translations.php:693
	__( 'Save as&hellip;', 'ang' ),

	// Reference: inc/elementor/class-typography.php:795
	// Reference: languages/ang-translations.php:697
	__( 'Export Theme Style Kit CSS', 'ang' ),

	// Reference: inc/elementor/class-typography.php:797
	// Reference: languages/ang-translations.php:701
	__( 'Export', 'ang' ),

	// Reference: inc/elementor/class-typography.php:837
	// Reference: languages/ang-translations.php:705
	__( 'A Style Kits control that adds padding to your outer sections. You can edit the values', 'ang' ),

	// Reference: inc/elementor/class-typography.php:843
	// Reference: languages/ang-translations.php:709
	__( 'No Padding', 'ang' ),

	// Reference: inc/elementor/class-typography.php:1104
	// Reference: languages/ang-translations.php:713
	__( 'Headings', 'ang' ),

	// Reference: inc/elementor/class-typography.php:1113
	// Reference: inc/elementor/sections/background-color-classes.php:133
	// Reference: inc/elementor/sections/background-color-classes.php:219
	// Reference: languages/ang-translations.php:719
	__( 'Headings Color', 'ang' ),

	// Reference: inc/elementor/class-typography.php:1126
	// Reference: languages/ang-translations.php:723
	__( 'Headings Font', 'ang' ),

	// Reference: inc/elementor/class-typography.php:1137
	// Reference: languages/ang-translations.php:727
	__( 'You can set individual heading font and colors below.', 'ang' ),

	// Reference: inc/elementor/kit/Kits_List_Table.php:63
	// Reference: languages/ang-translations.php:813
	__( 'No Kits found.', 'ang' ),

	// Reference: inc/elementor/kit/Kits_List_Table.php:83
	// Reference: languages/ang-translations.php:738
	/* translators: translators: %s: Human-readable time difference.
translators: translators: %s: Human-readable time difference. translators: translators: %s: Human-readable time difference. translators: translators: %s: Human-readable time difference. translators: translators: %s: Human-readable time difference. translators: translators: %s: Human-readable time difference. translators: translators: %s: Human-readable time difference. translators: translators: %s: Human-readable time difference. translators: translators: %s: Human-readable time difference. translators: translators: %s: Human-readable time difference. translators: translators: %s: Human-readable time difference. translators: translators: %s: Human-readable time difference. translators: translators: %s: Human-readable time difference. translators: translators: %s: Human-readable time difference. translators: translators: %s: Human-readable time difference. translators: translators: %s: Human-readable time difference. translators: translators: %s: Human-readable time difference. translators: translators: %s: Human-readable time difference. translators: translators: %s: Human-readable time difference. translators: translators: %s: Human-readable time difference. translators: translators: %s: Human-readable time difference. translators: translators: %s: Human-readable time difference. translators: translators: %s: Human-readable time difference. translators: translators: %s: Human-readable time difference. translators: translators: %s: Human-readable time difference. translators: translators: %s: Human-readable time difference. translators: translators: %s: Human-readable time difference. translators: translators: %s: Human-readable time difference. translators: translators: %s: Human-readable time difference. translators: translators: %s: Human-readable time difference. translators: translators: %s: Human-readable time difference. translators: translators: %s: Human-readable time difference. translators: translators: %s: Human-readable time difference. translators: translators: %s: Human-readable time difference. translators: translators: %s: Human-readable time difference. translators: translators: %s: Human-readable time difference. */
	__( '%s ago', 'ang' ),

	// Reference: inc/elementor/kit/Kits_List_Table.php:88
	// Reference: languages/ang-translations.php:743
	__( 'Published', 'ang' ),

	// Reference: inc/elementor/kit/Kits_List_Table.php:99
	// Reference: languages/ang-translations.php:817
	__( 'Entire Site', 'ang' ),

	// Reference: inc/elementor/kit/Kits_List_Table.php:101
	// Reference: languages/ang-translations.php:821
	__( 'None', 'ang' ),

	// Reference: inc/elementor/kit/Kits_List_Table.php:118
	// Reference: languages/ang-translations.php:748
	__( 'Title', 'ang' ),

	// Reference: inc/elementor/kit/Kits_List_Table.php:119
	// Reference: languages/ang-translations.php:826
	__( 'Instances', 'ang' ),

	// Reference: inc/elementor/kit/Kits_List_Table.php:120
	// Reference: languages/ang-translations.php:761
	__( 'Author', 'ang' ),

	// Reference: inc/elementor/kit/Kits_List_Table.php:121
	// Reference: languages/ang-translations.php:766
	__( 'Date', 'ang' ),

	// Reference: inc/elementor/kit/Kits_List_Table.php:138
	// Reference: languages/ang-translations.php:774
	/* translators: translators: %s: Kit Title
translators: translators: %s: Post Title translators: %s: Kit Title translators: translators: %s: Kit Title translators: translators: %s: Post Title translators: %s: Kit Title translators: translators: %s: Post Title translators: %s: Kit Title translators: translators: %s: Post Title translators: %s: Kit Title translators: translators: %s: Post Title translators: %s: Kit Title translators: translators: %s: Post Title translators: %s: Kit Title translators: translators: %s: Post Title translators: %s: Kit Title translators: translators: %s: Post Title translators: %s: Kit Title translators: translators: %s: Post Title translators: %s: Kit Title translators: translators: %s: Post Title translators: %s: Kit Title translators: translators: %s: Post Title translators: %s: Kit Title translators: translators: %s: Post Title translators: %s: Kit Title translators: translators: %s: Post Title translators: %s: Kit Title translators: translators: %s: Post Title translators: %s: Kit Title translators: translators: %s: Post Title translators: %s: Kit Title translators: translators: %s: Post Title translators: %s: Kit Title translators: translators: %s: Post Title translators: %s: Kit Title translators: translators: %s: Post Title translators: %s: Kit Title translators: translators: %s: Post Title translators: %s: Kit Title translators: translators: %s: Kit Title translators: translators: %s: Kit Title translators: translators: %s: Kit Title translators: translators: %s: Kit Title translators: translators: %s: Kit Title translators: translators: %s: Kit Title translators: translators: %s: Kit Title translators: translators: %s: Kit Title translators: translators: %s: Kit Title translators: translators: %s: Kit Title translators: translators: %s: Kit Title translators: translators: %s: Kit Title translators: translators: %s: Kit Title translators: translators: %s: Kit Title translators: translators: %s: Kit Title */
	__( '%s (Edit)', 'ang' ),

	// Reference: inc/elementor/kit/Kits_List_Table.php:140
	// Reference: languages/ang-translations.php:830
	__( 'Global Style Kit', 'ang' ),

	// Reference: inc/elementor/kit/Kits_List_Table.php:147
	// Reference: languages/ang-translations.php:779
	__( 'Edit', 'ang' ),

	// Reference: inc/elementor/kit/Kits_List_Table.php:148
	// Reference: languages/ang-translations.php:784
	__( 'Trash', 'ang' ),

	// Reference: inc/elementor/kit/Kits_List_Table.php:149
	// Reference: languages/ang-translations.php:834
	__( 'Export Theme Style Kit', 'ang' ),

	// Reference: inc/elementor/kit/Kits_List_Table.php:247
	// Reference: languages/ang-translations.php:797
	__( 'Move to Trash', 'ang' ),

	// Reference: inc/elementor/kit/Manager.php:305
	// Reference: languages/ang-translations.php:840
	/* translators: translators: %1$s: Settings library link. %2$s: Settings page link.
translators: translators: %1$s: Settings library link. %2$s: Settings page link. translators: translators: %1$s: Settings library link. %2$s: Settings page link. translators: translators: %1$s: Settings library link. %2$s: Settings page link. translators: translators: %1$s: Settings library link. %2$s: Settings page link. translators: translators: %1$s: Settings library link. %2$s: Settings page link. translators: translators: %1$s: Settings library link. %2$s: Settings page link. translators: translators: %1$s: Settings library link. %2$s: Settings page link. translators: translators: %1$s: Settings library link. %2$s: Settings page link. translators: translators: %1$s: Settings library link. %2$s: Settings page link. translators: translators: %1$s: Settings library link. %2$s: Settings page link. translators: translators: %1$s: Settings library link. %2$s: Settings page link. translators: translators: %1$s: Settings library link. %2$s: Settings page link. translators: translators: %1$s: Settings library link. %2$s: Settings page link. translators: translators: %1$s: Settings library link. %2$s: Settings page link. translators: translators: %1$s: Settings library link. %2$s: Settings page link. translators: translators: %1$s: Settings library link. %2$s: Settings page link. translators: translators: %1$s: Settings library link. %2$s: Settings page link. translators: translators: %1$s: Settings library link. %2$s: Settings page link. translators: translators: %1$s: Settings library link. %2$s: Settings page link. translators: translators: %1$s: Settings library link. %2$s: Settings page link. translators: translators: %1$s: Settings library link. %2$s: Settings page link. translators: translators: %1$s: Settings library link. %2$s: Settings page link. translators: translators: %1$s: Settings library link. %2$s: Settings page link. translators: translators: %1$s: Settings library link. %2$s: Settings page link. translators: translators: %1$s: Settings library link. %2$s: Settings page link. translators: translators: %1$s: Settings library link. %2$s: Settings page link. translators: translators: %1$s: Settings library link. %2$s: Settings page link. translators: translators: %1$s: Settings library link. %2$s: Settings page link. translators: translators: %1$s: Settings library link. %2$s: Settings page link. translators: translators: %1$s: Settings library link. %2$s: Settings page link. translators: translators: %1$s: Settings library link. %2$s: Settings page link. translators: translators: %1$s: Settings library link. %2$s: Settings page link. translators: translators: %1$s: Settings library link. %2$s: Settings page link. translators: translators: %1$s: Settings library link. %2$s: Settings page link. translators: translators: %1$s: Settings library link. %2$s: Settings page link. */
	__( 'Here is a quick overview of your available Theme Style Kits. They are also available in the %1$s. You can define a Global Theme Style Kit in %2$s.', 'ang' ),

	// Reference: inc/elementor/kit/Manager.php:306
	// Reference: languages/ang-translations.php:844
	__( 'Elementor Template Library', 'ang' ),

	// Reference: inc/elementor/Promotions.php:61
	// Reference: languages/ang-translations.php:848
	__( 'Layout Tools', 'ang' ),

	// Reference: inc/elementor/Promotions.php:63
	// Reference: languages/ang-translations.php:852
	__( 'Handy tools to clean inline styles from your existing layouts and make them global-design-ready. Highlight elements that have Classes or custom CSS.', 'ang' ),

	// Reference: inc/elementor/Promotions.php:98
	// Reference: languages/ang-translations.php:856
	__( 'Advanced Form Controls', 'ang' ),

	// Reference: inc/elementor/Promotions.php:100
	// Reference: languages/ang-translations.php:860
	__( 'Offers controls to customize form column/rows gap, label spacing, and form messages colors.', 'ang' ),

	// Reference: inc/elementor/Promotions.php:137
	// Reference: inc/Plugin.php:202
	// Reference: inc/register-settings.php:76
	// Reference: languages/ang-translations.php:868
	/* translators: translators: %1$s: Link to Style Kits Pro. %2$s: Go Pro text.
translators: translators: %1$s: Link to Style Kits Pro. %2$s: Go Pro text. translators: translators: %1$s: Link to Style Kits Pro. %2$s: Go Pro text. translators: translators: %1$s: Link to Style Kits Pro. %2$s: Go Pro text. translators: translators: %1$s: Link to Style Kits Pro. %2$s: Go Pro text. translators: translators: %1$s: Link to Style Kits Pro. %2$s: Go Pro text. translators: translators: %1$s: Link to Style Kits Pro. %2$s: Go Pro text. translators: translators: %1$s: Link to Style Kits Pro. %2$s: Go Pro text. translators: translators: %1$s: Link to Style Kits Pro. %2$s: Go Pro text. translators: translators: %1$s: Link to Style Kits Pro. %2$s: Go Pro text. translators: translators: %1$s: Link to Style Kits Pro. %2$s: Go Pro text. translators: translators: %1$s: Link to Style Kits Pro. %2$s: Go Pro text. translators: translators: %1$s: Link to Style Kits Pro. %2$s: Go Pro text. translators: translators: %1$s: Link to Style Kits Pro. %2$s: Go Pro text. translators: translators: %1$s: Link to Style Kits Pro. %2$s: Go Pro text. translators: translators: %1$s: Link to Style Kits Pro. %2$s: Go Pro text. translators: translators: %1$s: Link to Style Kits Pro. %2$s: Go Pro text. translators: translators: %1$s: Link to Style Kits Pro. %2$s: Go Pro text. translators: translators: %1$s: Link to Style Kits Pro. %2$s: Go Pro text. translators: translators: %1$s: Link to Style Kits Pro. %2$s: Go Pro text. translators: translators: %1$s: Link to Style Kits Pro. %2$s: Go Pro text. translators: translators: %1$s: Link to Style Kits Pro. %2$s: Go Pro text. translators: translators: %1$s: Link to Style Kits Pro. %2$s: Go Pro text. translators: translators: %1$s: Link to Style Kits Pro. %2$s: Go Pro text. translators: translators: %1$s: Link to Style Kits Pro. %2$s: Go Pro text. translators: translators: %1$s: Link to Style Kits Pro. %2$s: Go Pro text. translators: translators: %1$s: Link to Style Kits Pro. %2$s: Go Pro text. translators: translators: %1$s: Link to Style Kits Pro. %2$s: Go Pro text. translators: translators: %1$s: Link to Style Kits Pro. %2$s: Go Pro text. translators: translators: %1$s: Link to Style Kits Pro. %2$s: Go Pro text. translators: translators: %1$s: Link to Style Kits Pro. %2$s: Go Pro text. translators: translators: %1$s: Link to Style Kits Pro. %2$s: Go Pro text. translators: translators: %1$s: Link to Style Kits Pro. %2$s: Go Pro text. translators: translators: %1$s: Link to Style Kits Pro. %2$s: Go Pro text. translators: translators: %1$s: Link to Style Kits Pro. %2$s: Go Pro text. translators: translators: %1$s: Link to Style Kits Pro. %2$s: Go Pro text. */
	__( 'Go Pro', 'ang' ),

	// Reference: inc/elementor/Promotions.php:156
	// Reference: languages/ang-translations.php:872
	__( 'Accent', 'ang' ),

	// Reference: inc/elementor/Promotions.php:165
	// Reference: languages/ang-translations.php:876
	__( 'Accent Background Color', 'ang' ),

	// Reference: inc/elementor/Promotions.php:167
	// Reference: languages/ang-translations.php:880
	__( 'Enjoy better background color control in your layouts by adding a third background color class. Available in Style Kits Pro.', 'ang' ),

	// Reference: inc/elementor/sections/background-color-classes.php:61
	// Reference: languages/ang-translations.php:884
	__( 'Light', 'ang' ),

	// Reference: inc/elementor/sections/background-color-classes.php:68
	// Reference: languages/ang-translations.php:888
	__( 'Add the class <strong>sk-light-bg</strong> to a section or column to apply these colors.', 'ang' ),

	// Reference: inc/elementor/sections/background-color-classes.php:147
	// Reference: languages/ang-translations.php:892
	__( 'Dark', 'ang' ),

	// Reference: inc/elementor/sections/background-color-classes.php:154
	// Reference: languages/ang-translations.php:896
	__( 'Add the class <strong>sk-dark-bg</strong> to a section or column to apply these colors.', 'ang' ),

	// Reference: inc/elementor/tags/class-dark-background.php:14
	// Reference: languages/ang-translations.php:900
	__( 'Dark Background', 'ang' ),

	// Reference: inc/elementor/tags/class-light-background.php:14
	// Reference: languages/ang-translations.php:904
	__( 'Light Background', 'ang' ),

	// Reference: inc/register-settings.php:37
	// Reference: languages/ang-translations.php:908
	__( 'Style Kits Library', 'ang' ),

	// Reference: inc/register-settings.php:38
	// Reference: languages/ang-translations.php:912
	__( 'Library', 'ang' ),

	// Reference: inc/register-settings.php:45
	// Reference: inc/settings/views/html-admin-settings.php:28
	// Reference: languages/ang-translations.php:917
	__( 'Style Kits Settings', 'ang' ),

	// Reference: inc/register-settings.php:65
	// Reference: inc/register-settings.php:66
	// Reference: languages/ang-translations.php:922
	__( 'Welcome to Style Kits', 'ang' ),

	// Reference: inc/register-settings.php:253
	// Reference: languages/ang-translations.php:930
	__( 'Style Kits are now integrated into Elementor Theme Styles', 'ang' ),

	// Reference: inc/register-settings.php:256
	// Reference: languages/ang-translations.php:934
	__( 'With the introduction of Theme Styles in Elementor v2.9.0, 	Style Kits are now <strong>integrated into the Theme Styles panel</strong>, bringing you a consistent, native experience.', 'ang' ),

	// Reference: inc/register-settings.php:261
	// Reference: languages/ang-translations.php:938
	__( 'See what’s different in this quick video above.', 'ang' ),

	// Reference: inc/register-settings.php:265
	// Reference: languages/ang-translations.php:942
	__( 'Need help?', 'ang' ),

	// Reference: inc/register-settings.php:267
	// Reference: languages/ang-translations.php:946
	__( 'Go to docs', 'ang' ),

	// Reference: inc/register-settings.php:268
	// Reference: languages/ang-translations.php:950
	__( 'Send a support ticket', 'ang' ),

	// Reference: inc/settings/class-settings-extensions.php:25
	// Reference: languages/ang-translations.php:954
	__( 'Extensions', 'ang' ),

	// Reference: inc/settings/class-settings-general.php:26
	// Reference: inc/settings/class-settings-general.php:38
	// Reference: languages/ang-translations.php:959
	__( 'General', 'ang' ),

	// Reference: inc/settings/class-settings-general.php:61
	// Reference: languages/ang-translations.php:963
	__( 'Elementor Settings', 'ang' ),

	// Reference: inc/settings/class-settings-general.php:69
	// Reference: languages/ang-translations.php:969
	/* translators: translators: %s: Style Kit Documentation link
translators: translators: %s: Style Kit Documentation link translators: translators: %s: Style Kit Documentation link translators: translators: %s: Style Kit Documentation link translators: translators: %s: Style Kit Documentation link translators: translators: %s: Style Kit Documentation link translators: translators: %s: Style Kit Documentation link translators: translators: %s: Style Kit Documentation link translators: translators: %s: Style Kit Documentation link translators: translators: %s: Style Kit Documentation link translators: translators: %s: Style Kit Documentation link translators: translators: %s: Style Kit Documentation link translators: translators: %s: Style Kit Documentation link translators: translators: %s: Style Kit Documentation link translators: translators: %s: Style Kit Documentation link translators: translators: %s: Style Kit Documentation link translators: translators: %s: Style Kit Documentation link translators: translators: %s: Style Kit Documentation link translators: translators: %s: Style Kit Documentation link translators: translators: %s: Style Kit Documentation link translators: translators: %s: Style Kit Documentation link translators: translators: %s: Style Kit Documentation link translators: translators: %s: Style Kit Documentation link translators: translators: %s: Style Kit Documentation link translators: translators: %s: Style Kit Documentation link translators: translators: %s: Style Kit Documentation link translators: translators: %s: Style Kit Documentation link translators: translators: %s: Style Kit Documentation link translators: translators: %s: Style Kit Documentation link translators: translators: %s: Style Kit Documentation link translators: translators: %s: Style Kit Documentation link translators: translators: %s: Style Kit Documentation link translators: translators: %s: Style Kit Documentation link translators: translators: %s: Style Kit Documentation link translators: translators: %s: Style Kit Documentation link translators: translators: %s: Style Kit Documentation link */
	__( 'Choosing a Style Kit will make it global and apply site-wide. Learn more about %s.', 'ang' ),

	// Reference: inc/settings/class-settings-general.php:70
	// Reference: languages/ang-translations.php:973
	__( 'Style kits', 'ang' ),

	// Reference: inc/settings/class-settings-gopro.php:27
	// Reference: languages/ang-translations.php:977
	__( 'Style Kits Pro', 'ang' ),

	// Reference: inc/settings/class-settings-misc.php:23
	// Reference: languages/ang-translations.php:981
	__( 'Misc', 'ang' ),

	// Reference: inc/settings/class-settings-misc.php:42
	// Reference: languages/ang-translations.php:985
	__( 'Usage Data Tracking', 'ang' ),

	// Reference: inc/settings/class-settings-misc.php:43
	// Reference: languages/ang-translations.php:989
	__( 'Opt-in to our anonymous plugin data collection and to updates', 'ang' ),

	// Reference: inc/settings/class-settings-misc.php:48
	// Reference: languages/ang-translations.php:993
	__( 'We guarantee no sensitive data is collected. ', 'ang' ),

	// Reference: inc/settings/class-settings-misc.php:48
	// Reference: languages/ang-translations.php:997
	__( 'More Info', 'ang' ),

	// Reference: inc/settings/class-settings-misc.php:51
	// Reference: languages/ang-translations.php:1001
	__( 'Remove Data on Uninstall', 'ang' ),

	// Reference: inc/settings/class-settings-misc.php:52
	// Reference: languages/ang-translations.php:1005
	__( 'Check this box to remove all data stored by Style Kit for Elementor plugin, including license info, user settings, import history etc. Any imported or manually saved Style Kits are not removed.', 'ang' ),

	// Reference: inc/settings/class-settings-version-control.php:25
	// Reference: languages/ang-translations.php:1009
	__( 'Version Control', 'ang' ),

	// Reference: inc/settings/class-settings-version-control.php:40
	// Reference: languages/ang-translations.php:1013
	__( 'Rollback Versions', 'ang' ),

	// Reference: inc/settings/class-settings-version-control.php:41
	// Reference: languages/ang-translations.php:1017
	__( 'If you are having issues with current version of Style Kits for Elementor, you can rollback to a previous stable version.', 'ang' ),

	// Reference: inc/settings/class-settings-version-control.php:46
	// Reference: languages/ang-translations.php:1021
	__( 'Rollback Style Kits', 'ang' ),

	// Reference: inc/settings/class-settings-version-control.php:58
	// Reference: languages/ang-translations.php:1025
	__( 'Reinstall this version', 'ang' ),

	// Reference: inc/settings/class-settings-version-control.php:65
	// Reference: languages/ang-translations.php:1029
	__( 'Beta Features', 'ang' ),

	// Reference: inc/settings/class-settings-version-control.php:70
	// Reference: languages/ang-translations.php:1033
	__( 'Become a beta tester', 'ang' ),

	// Reference: inc/settings/class-settings-version-control.php:71
	// Reference: languages/ang-translations.php:1037
	__( 'Check this box to turn on beta updates for Style Kits and Style Kits Pro. The update will not be installed automatically, you always have the option to ignore it.', 'ang' ),

	// Reference: inc/settings/views/html-admin-settings-gopro.php:14
	// Reference: languages/ang-translations.php:1041
	__( 'Style Kits Pro gives you access to <u>premium template kits, blocks and Style Kits</u>, <br>plus a number of extra design features to power-up your design workflow in Elementor.', 'ang' ),

	// Reference: inc/settings/views/html-admin-settings-gopro.php:16
	// Reference: languages/ang-translations.php:1045
	__( '<strong>User role management</strong> so you can restrict access to Style Kits for your clients or editors', 'ang' ),

	// Reference: inc/settings/views/html-admin-settings-gopro.php:17
	// Reference: languages/ang-translations.php:1049
	__( 'Handy tools to <strong>highlight Elements</strong> using custom CSS or custom CSS classes', 'ang' ),

	// Reference: inc/settings/views/html-admin-settings-gopro.php:18
	// Reference: languages/ang-translations.php:1053
	__( '<strong>Tools to clean-up</strong> any of your templates and layouts from inline styles, and make them Style-Kit-ready', 'ang' ),

	// Reference: inc/settings/views/html-admin-settings-gopro.php:19
	// Reference: languages/ang-translations.php:1057
	__( '<strong>Unsplash integration</strong> so you can import images from Unsplash right into your WordPress media gallery', 'ang' ),

	// Reference: inc/settings/views/html-admin-settings-gopro.php:21
	// Reference: languages/ang-translations.php:1061
	__( 'And many more meaningful features', 'ang' ),

	// Reference: inc/settings/views/html-admin-settings-gopro.php:22
	// Reference: languages/ang-translations.php:1065
	__( 'Explore Style Kits Pro', 'ang' ),

	// Reference: inc/settings/views/html-admin-settings.php:53
	// Reference: languages/ang-translations.php:1069
	__( 'Save changes', 'ang' ),

	// Reference: inc/settings/views/html-admin-settings.php:64
	// Reference: languages/ang-translations.php:1073
	__( 'Upgrade to Style Kits Pro with a 15% discount', 'ang' ),

	// Reference: inc/settings/views/html-admin-settings.php:66
	// Reference: languages/ang-translations.php:1077
	__( 'Unlimited access to Pro Template Kits, Blocks, and Theme Style presets', 'ang' ),

	// Reference: inc/settings/views/html-admin-settings.php:67
	// Reference: languages/ang-translations.php:1081
	__( 'More Theme Style UI Controls', 'ang' ),

	// Reference: inc/settings/views/html-admin-settings.php:68
	// Reference: languages/ang-translations.php:1085
	__( 'User Role management', 'ang' ),

	// Reference: inc/settings/views/html-admin-settings.php:69
	// Reference: languages/ang-translations.php:1089
	__( 'Unsplash integration', 'ang' ),

	// Reference: inc/settings/views/html-admin-settings.php:70
	// Reference: languages/ang-translations.php:1093
	__( 'Better color management', 'ang' ),

	// Reference: inc/settings/views/html-admin-settings.php:71
	// Reference: languages/ang-translations.php:1097
	__( 'Smart layout tools', 'ang' ),

	// Reference: inc/settings/views/html-admin-settings.php:74
	// Reference: languages/ang-translations.php:1101
	__( 'Find out more', 'ang' ),

	// Reference: inc/settings/views/html-admin-settings.php:77
	// Reference: languages/ang-translations.php:1105
	__( 'Your Email', 'ang' ),

	// Reference: inc/settings/views/html-admin-settings.php:78
	// Reference: languages/ang-translations.php:1109
	__( 'First Name', 'ang' ),

	// Reference: inc/settings/views/html-admin-settings.php:79
	// Reference: languages/ang-translations.php:1113
	__( 'Last Name', 'ang' ),

	// Reference: inc/settings/views/html-admin-settings.php:80
	// Reference: languages/ang-translations.php:1117
	__( 'Send me the coupon', 'ang' ),

	// Reference: inc/settings/views/html-admin-settings.php:87
	// Reference: languages/ang-translations.php:1123
	/* translators: translators: %s: Link to AnalogWP privacy policy.
translators: translators: %s: Link to AnalogWP privacy policy. translators: translators: %s: Link to AnalogWP privacy policy. translators: translators: %s: Link to AnalogWP privacy policy. translators: translators: %s: Link to AnalogWP privacy policy. translators: translators: %s: Link to AnalogWP privacy policy. translators: translators: %s: Link to AnalogWP privacy policy. translators: translators: %s: Link to AnalogWP privacy policy. translators: translators: %s: Link to AnalogWP privacy policy. translators: translators: %s: Link to AnalogWP privacy policy. translators: translators: %s: Link to AnalogWP privacy policy. translators: translators: %s: Link to AnalogWP privacy policy. translators: translators: %s: Link to AnalogWP privacy policy. translators: translators: %s: Link to AnalogWP privacy policy. translators: translators: %s: Link to AnalogWP privacy policy. translators: translators: %s: Link to AnalogWP privacy policy. translators: translators: %s: Link to AnalogWP privacy policy. translators: translators: %s: Link to AnalogWP privacy policy. translators: translators: %s: Link to AnalogWP privacy policy. translators: translators: %s: Link to AnalogWP privacy policy. translators: translators: %s: Link to AnalogWP privacy policy. translators: translators: %s: Link to AnalogWP privacy policy. translators: translators: %s: Link to AnalogWP privacy policy. translators: translators: %s: Link to AnalogWP privacy policy. translators: translators: %s: Link to AnalogWP privacy policy. translators: translators: %s: Link to AnalogWP privacy policy. translators: translators: %s: Link to AnalogWP privacy policy. translators: translators: %s: Link to AnalogWP privacy policy. translators: translators: %s: Link to AnalogWP privacy policy. translators: translators: %s: Link to AnalogWP privacy policy. translators: translators: %s: Link to AnalogWP privacy policy. translators: translators: %s: Link to AnalogWP privacy policy. translators: translators: %s: Link to AnalogWP privacy policy. translators: translators: %s: Link to AnalogWP privacy policy. translators: translators: %s: Link to AnalogWP privacy policy. translators: translators: %s: Link to AnalogWP privacy policy. */
	__( 'By submitting your details, you agree to our %s.', 'ang' ),

	// Reference: inc/settings/views/html-admin-settings.php:88
	// Reference: languages/ang-translations.php:1127
	__( 'privacy policy', 'ang' ),

	// Reference: inc/settings/views/html-admin-settings.php:99
	// Reference: languages/ang-translations.php:1131
	__( 'Need help with Style Kits?', 'ang' ),

	// Reference: inc/settings/views/html-admin-settings.php:100
	// Reference: languages/ang-translations.php:1135
	__( 'Visit the online docs', 'ang' ),

	// Reference: inc/settings/views/html-admin-settings.php:104
	// Reference: languages/ang-translations.php:1139
	__( 'Join our Facebook group', 'ang' ),

	// Reference: inc/settings/views/html-admin-settings.php:106
	// Reference: languages/ang-translations.php:1143
	__( 'Get insights, tips and updates in our facebook community.', 'ang' ),

	// Reference: inc/settings/views/html-admin-settings.php:107
	// Reference: languages/ang-translations.php:1147
	__( 'Join now', 'ang' ),

	// Reference: inc/settings/views/html-admin-settings.php:111
	// Reference: languages/ang-translations.php:1151
	__( 'Sign up for email updates', 'ang' ),

	// Reference: inc/settings/views/html-admin-settings.php:112
	// Reference: languages/ang-translations.php:1155
	__( 'Stay in the loop with Style Kits development by signing up to our newsletter.', 'ang' ),

	// Reference: inc/settings/views/html-admin-settings.php:115
	// Reference: languages/ang-translations.php:1159
	__( 'Sign me up', 'ang' ),

	// Reference: inc/settings/views/html-admin-settings.php:117
	// Reference: languages/ang-translations.php:1163
	__( 'By signing up you agree to our', 'ang' ),

	// Reference: inc/settings/views/html-admin-settings.php:117
	// Reference: languages/ang-translations.php:1167
	__( 'privacy and terms', 'ang' ),

	// Reference: inc/Utils.php:135
	// Reference: inc/Utils.php:652
	// Reference: languages/ang-translations.php:1174
	/* translators: translators: Global Style Kit post title.
translators: translators: Global Style Kit post title. translators: translators: Global Style Kit post title. translators: translators: Global Style Kit post title. translators: translators: Global Style Kit post title. translators: translators: Global Style Kit post title. translators: translators: Global Style Kit post title. translators: translators: Global Style Kit post title. translators: translators: Global Style Kit post title. translators: translators: Global Style Kit post title. translators: translators: Global Style Kit post title. translators: translators: Global Style Kit post title. translators: translators: Global Style Kit post title. translators: translators: Global Style Kit post title. translators: translators: Global Style Kit post title. translators: translators: Global Style Kit post title. translators: translators: Global Style Kit post title. translators: translators: Global Style Kit post title. translators: translators: Global Style Kit post title. translators: translators: Global Style Kit post title. translators: translators: Global Style Kit post title. translators: translators: Global Style Kit post title. translators: translators: Global Style Kit post title. translators: translators: Global Style Kit post title. translators: translators: Global Style Kit post title. translators: translators: Global Style Kit post title. translators: translators: Global Style Kit post title. translators: translators: Global Style Kit post title. translators: translators: Global Style Kit post title. translators: translators: Global Style Kit post title. translators: translators: Global Style Kit post title. translators: translators: Global Style Kit post title. translators: translators: Global Style Kit post title. translators: translators: Global Style Kit post title. translators: translators: Global Style Kit post title. translators: translators: Global Style Kit post title. */
	__( 'Global: %s', 'ang' ),

	// Reference: languages/ang-translations.php:731
	__( 'No posts found.', 'ang' ),

	// Reference: languages/ang-translations.php:752
	__( 'Type', 'ang' ),

	// Reference: languages/ang-translations.php:756
	__( 'Kit', 'ang' ),

	// Reference: languages/ang-translations.php:788
	__( 'View', 'ang' ),

	// Reference: languages/ang-translations.php:792
	__( 'Edit with Elementor', 'ang' ),

	// Reference: languages/ang-translations.php:801
	__( 'Filter by Style Kit', 'ang' ),

	// Reference: languages/ang-translations.php:805
	__( 'Filter', 'ang' ),

	// Reference: languages/ang-translations.php:809
	__( 'Instance List', 'ang' ),

	// Reference: languages/ang-translations.php:926
	__( 'Instances List', 'ang' ),

	// Reference: languages/ang-translations.php:1177
	__( 'Exit preview', 'ang' ),

	// Reference: languages/ang-translations.php:1180
	__( 'Templates', 'ang' ),

	// Reference: languages/ang-translations.php:1183
	__( 'Blocks', 'ang' ),

	// Reference: languages/ang-translations.php:1186
	__( 'To import Pro ', 'ang' ),

	// Reference: languages/ang-translations.php:1189
	__( ', you’ll need an active ', 'ang' ),

	// Reference: languages/ang-translations.php:1192
	__( 'New', 'ang' ),

	// Reference: languages/ang-translations.php:1195
	__( 'This template requires an updated version, please update your plugin to latest version.', 'ang' ),

	// Reference: languages/ang-translations.php:1198
	__( 'templates', 'ang' ),

	// Reference: languages/ang-translations.php:1201
	__( 'Template', 'ang' ),

	// Reference: languages/ang-translations.php:1204
	__( 'Block', 'ang' ),

	// Reference: languages/ang-translations.php:1207
	__( 'Add Style Kits', 'ang' ),

	// Reference: languages/ang-translations.php:1210
	__( 'The block has been imported and is now available in the', 'ang' ),

	// Reference: languages/ang-translations.php:1213
	__( 'Elementor section library', 'ang' ),

	// Reference: languages/ang-translations.php:1216
	__( 'Upgrade to Style Kits Pro', 'ang' ),

	// Reference: languages/ang-translations.php:1219
	__( 'Enjoy unlimited access to the template and block library, along with many more features in Style Kits Pro.', 'ang' ),

	// Reference: languages/ang-translations.php:1222
	__( 'Learn More', 'ang' ),

	// Reference: languages/ang-translations.php:1225
	__( 'Quick video', 'ang' ),

	// Reference: languages/ang-translations.php:1228
	__( 'Show Pro Blocks', 'ang' ),

	// Reference: languages/ang-translations.php:1231
	__( 'Loading blocks...', 'ang' ),

	// Reference: languages/ang-translations.php:1234
	__( 'View Templates', 'ang' ),

	// Reference: languages/ang-translations.php:1237
	__( 'All template types', 'ang' ),

	// Reference: languages/ang-translations.php:1240
	__( 'Newest first', 'ang' ),

	// Reference: languages/ang-translations.php:1243
	__( 'Popular', 'ang' ),

	// Reference: languages/ang-translations.php:1246
	__( 'Both Free and Pro', 'ang' ),

	// Reference: languages/ang-translations.php:1249
	__( 'Pro', 'ang' ),

	// Reference: languages/ang-translations.php:1252
	__( 'Free', 'ang' ),

	// Reference: languages/ang-translations.php:1255
	__( 'Template Kit', 'ang' ),

	// Reference: languages/ang-translations.php:1258
	__( '%s in WordPress dashboard.', 'ang' ),

	// Reference: languages/ang-translations.php:1261
	__( 'Manage your Style Kits', 'ang' ),

	// Reference: languages/ang-translations.php:1264
	__( 'These are some Style Kit presets that you can use as a starting point. Once you import a Style Kit, it will be added to your', 'ang' ),

	// Reference: languages/ang-translations.php:1267
	__( 'Style Kits list', 'ang' ),

	// Reference: languages/ang-translations.php:1270
	__( 'Back to Library', 'ang' ),

	// Reference: languages/ang-translations.php:1273
	__( 'Global', 'ang' ),

	// Reference: languages/ang-translations.php:1276
	__( 'Installed', 'ang' ),

	// Reference: languages/ang-translations.php:1279
	__( 'Learn more about this in %s.', 'ang' ),

	// Reference: languages/ang-translations.php:1282
	__( 'Style Kits Docs', 'ang' ),

	// Reference: languages/ang-translations.php:1285
	__( 'Choose a Style Kit...', 'ang' ),

	// Reference: languages/ang-translations.php:1288
	__( 'Next', 'ang' ),

	// Reference: languages/ang-translations.php:1291
	__( 'Change Style Kit', 'ang' ),

	// Reference: languages/ang-translations.php:1294
	__( 'Import this template to your library to make it available in your Elementor ', 'ang' ),

	// Reference: languages/ang-translations.php:1297
	__( 'Saved Templates', 'ang' ),

	// Reference: languages/ang-translations.php:1300
	__( 'Select a Style Kit to apply on this layout', 'ang' ),

	// Reference: languages/ang-translations.php:1303
	__( 'Close', 'ang' ),

	// Reference: languages/ang-translations.php:1306
	__( 'Templates library refreshed', 'ang' ),

	// Reference: languages/ang-translations.php:1309
	__( 'Error refreshing templates library, please try again.', 'ang' ),

	// Reference: languages/ang-translations.php:1312
	__( 'Syncing...', 'ang' ),

	// Reference: languages/ang-translations.php:1315
	__( 'Sync Library', 'ang' ),

	// Reference: languages/ang-translations.php:1318
	__( 'Show All', 'ang' ),

	// Reference: languages/ang-translations.php:1321
	__( 'Latest', 'ang' ),

	// Reference: languages/ang-translations.php:1324
	__( 'Back to Kits', 'ang' ),

	// Reference: languages/ang-translations.php:1327
	__( 'Choose a Theme Style Kit to apply on the page.', 'ang' ),

	// Reference: languages/ang-translations.php:1330
	__( 'Import template', 'ang' ),

	// Reference: languages/ang-translations.php:1333
	__( 'Style Kits Blocks', 'ang' ),

	// Reference: languages/ang-translations.php:1336
	__( 'Search blocks', 'ang' ),

	// Reference: languages/ang-translations.php:1339
	__( 'Blocks Library', 'ang' ),

	// Reference: inc/elementor/class-colors.php:154
	// Reference: languages/ang-translations.php:1343
	_x( 'Accent Colors', 'Section Title', 'ang' ),

	// Reference: inc/elementor/Promotions.php:50
	// Reference: languages/ang-translations.php:1347
	_x( 'Layout Tools', 'Section Title', 'ang' ),

	// Reference: inc/elementor/Promotions.php:87
	// Reference: languages/ang-translations.php:1351
	_x( 'Forms (Extended)', 'Section Title', 'ang' ),

	// Reference: inc/elementor/sections/background-color-classes.php:52
	// Reference: languages/ang-translations.php:1355
	_x( 'Background Color Classes', 'Section Title', 'ang' ),

	// Reference: inc/elementor/class-post-type.php:34
	// Reference: languages/ang-translations.php:1359
	_x( 'Style Kits', 'admin menu', 'ang' ),

	// Reference: inc/elementor/class-post-type.php:35
	// Reference: languages/ang-translations.php:1363
	_x( 'Style Kit', 'add new on admin bar', 'ang' ),

	// Reference: inc/elementor/class-post-type.php:36
	// Reference: languages/ang-translations.php:1367
	_x( 'Add New', 'book', 'ang' ),

	// Reference: inc/elementor/kit/Kits_List_Table.php:265
	// Reference: languages/ang-translations.php:1374
	/* translators: translators: %s: Number of posts.
translators: translators: %s: Number of posts. translators: translators: %s: Number of posts. translators: translators: %s: Number of posts. translators: translators: %s: Number of posts. translators: translators: %s: Number of posts. translators: translators: %s: Number of posts. translators: translators: %s: Number of posts. translators: translators: %s: Number of posts. translators: translators: %s: Number of posts. translators: translators: %s: Number of posts. translators: translators: %s: Number of posts. translators: translators: %s: Number of posts. translators: translators: %s: Number of posts. translators: translators: %s: Number of posts. translators: translators: %s: Number of posts. translators: translators: %s: Number of posts. translators: translators: %s: Number of posts. translators: translators: %s: Number of posts. translators: translators: %s: Number of posts. translators: translators: %s: Number of posts. translators: translators: %s: Number of posts. translators: translators: %s: Number of posts. translators: translators: %s: Number of posts. translators: translators: %s: Number of posts. translators: translators: %s: Number of posts. translators: translators: %s: Number of posts. translators: translators: %s: Number of posts. translators: translators: %s: Number of posts. translators: translators: %s: Number of posts. translators: translators: %s: Number of posts. translators: translators: %s: Number of posts. translators: translators: %s: Number of posts. translators: translators: %s: Number of posts. translators: translators: %s: Number of posts. translators: translators: %s: Number of posts. */
	_nx_noop( 'All <span class="count">(%s)</span>',  'All <span class="count">(%s)</span>', 'posts', 'ang' ),

	// Reference: inc/settings/class-settings-general.php:66
	// Reference: languages/ang-translations.php:1378
	_x( 'Global Style Kit', 'settings title', 'ang' )
);
/* THIS IS THE END OF THE GENERATED FILE */
